#define version_string "0.50"
#define release_string "20130305"
